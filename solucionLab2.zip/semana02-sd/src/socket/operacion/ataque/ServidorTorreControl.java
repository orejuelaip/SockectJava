package socket.operacion.ataque;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import socket.operacion.dto.MensajeSecretoDTO;

public class ServidorTorreControl {
	
	private static final int PUERTO_ULTRA_SECRETO = 5544;
	private static ServerSocket servidor = null;
	

	public static void main(String[] args) {
		
		try {
			levantarServidor();
		
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	private static void levantarServidor() throws Exception {
		System.out.println("inicio levantarServidor()");
		//ABRIR EL CANAL DE COMUNICACION USANDO SOCKETS
		servidor = new ServerSocket(PUERTO_ULTRA_SECRETO);
		System.out.println("TORRE CONTROL ESCUCHANDO MENSAJES");
		Socket socket =  servidor.accept();//ACTIVA EL ESCUCHADOR
		
		System.out.println("TORRE CONTROL DETECT� UN MENSAJE");
		
		//definimos los flujos
		ObjectInputStream flujoEntrada = new ObjectInputStream(socket.getInputStream());
		
		//obtengo el mensaje del flujo
		MensajeSecretoDTO msj = (MensajeSecretoDTO)flujoEntrada.readObject();
		
		//PROCESAR EL MENSAJE
		System.out.println("ID SOLDADO: "+msj.getIdSoldado());
		System.out.println("COORDENADA: "+msj.getCoordenada());
		System.out.println("MENSAJE SOLDADO: "+msj.getMensajeSoldado());
		
		msj.setRespuestaTorre("ATACAR!!!");
		
		//Preparamos el envio de la respuesta al soldado
		ObjectOutputStream flujoSalida = new ObjectOutputStream(socket.getOutputStream());
		flujoSalida.writeObject(msj);
		
		//cerramos canal de comunicaci�n
		socket.close();
		
		
		System.out.println("fin levantarServidor()");
	}
	
	

}
