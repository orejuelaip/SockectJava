package socket.operacion.ataque;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import socket.operacion.dto.MensajeSecretoDTO;

public class SoldadoTerminalCliente {
	
	private static final int PUERTO_ULTRA_SECRETO = 5544;
	private static final String HOST_TORRE_CONTROL = "localhost";
	

	public static void main(String[] args) {
		try {
			System.out.println("SOLDADO DELTA1 - INTENTANDO COMUNICARSE");
			
			//establecemos canal de comunicacion con la torre
			Socket socket = new Socket(HOST_TORRE_CONTROL, PUERTO_ULTRA_SECRETO);
			
			System.out.println("CONEXI�N EXITOSA CON LA TORRE DE CONTROL!");
			
			//definimos el flujo de salida de datos
			ObjectOutputStream flujoSalida = new ObjectOutputStream(socket.getOutputStream());
			System.out.println("PREPARANDO ENVIO DE MENSAJE");
			
			MensajeSecretoDTO mensaje = new MensajeSecretoDTO();
			mensaje.setIdSoldado("DELTA1");
			mensaje.setCoordenada("LT. 1.4.44.44");
			mensaje.setMensajeSoldado("OBJETIVO EN LA MIRA - PERMISO PARA ATACAR");
			
			//enviamos el objeto mensaje sobre el flujo 
			flujoSalida.writeObject(mensaje);
			System.out.println("MENSAJE ENVIADO");
			
			//
			ObjectInputStream flujoEntrada = new ObjectInputStream(socket.getInputStream());
			MensajeSecretoDTO mensajeRespuesta = (MensajeSecretoDTO)flujoEntrada.readObject();
			System.out.println("RESPUESTA TORRE DE CONTROL: "+mensajeRespuesta.getRespuestaTorre());
			
			//cerramos el canal de comunicaci�n
			socket.close();
			
			
			
		}catch (Exception e) {
			System.out.println("CONEXI�N F�LLIDA!");
			e.printStackTrace();
		}

	}

}
